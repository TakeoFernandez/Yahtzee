class Main {
  public static void main(String[] args) {
    Dice d = new Dice();
    d.roll();
    d.repaint();
    
   // System.out.println(System.getProperty("user.dir") + "/faces/" + "Alea_");
    
    // d.roll(d.getFaces());
    // for(Face f: d.getFaces()){
    //   System.out.println(f.getSide());
    // }
    // for(Face f: d.getFaces()){
    //   f.switchKeep();
    // }
    // d.roll(d.getFaces());
    // for(Face f: d.getFaces()){
    //   System.out.println(f.getSide());
    // }
    // for(Face f: d.getFaces()){
    //   f.switchKeep();
    // }
    // d.roll(d.getFaces());
    // for(Face f: d.getFaces()){
    //   System.out.println(f.getSide());
    // }
    //
    
  }
}